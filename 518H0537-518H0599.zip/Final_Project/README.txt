Open IDEA
Open folder demo->test
Run project 
Run CoffeeShop.java