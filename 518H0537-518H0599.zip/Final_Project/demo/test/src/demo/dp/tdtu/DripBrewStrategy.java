package demo.dp.tdtu;

public class DripBrewStrategy  implements  BrewStrategy{
    public void brewCoffee() {
        System.out.println("Dripping coffee through filter...");
    }
}
