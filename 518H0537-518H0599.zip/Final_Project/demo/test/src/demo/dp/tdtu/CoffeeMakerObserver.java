package demo.dp.tdtu;

public interface CoffeeMakerObserver {
    void onCoffeeMade();
}
