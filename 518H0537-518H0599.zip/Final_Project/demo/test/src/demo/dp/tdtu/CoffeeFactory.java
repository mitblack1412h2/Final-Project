package demo.dp.tdtu;

public interface CoffeeFactory {
    Coffee createCoffee();
}
