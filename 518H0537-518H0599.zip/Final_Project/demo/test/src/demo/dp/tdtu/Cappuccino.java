package demo.dp.tdtu;

public class Cappuccino implements Coffee {
    public void prepare() {
        System.out.println("Preparing cappuccino...");
    }
}
