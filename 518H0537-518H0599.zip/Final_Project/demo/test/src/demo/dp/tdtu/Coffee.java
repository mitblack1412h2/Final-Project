package demo.dp.tdtu;

public interface Coffee {
    void prepare();
}
