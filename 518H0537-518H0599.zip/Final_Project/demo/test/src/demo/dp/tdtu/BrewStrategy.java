package demo.dp.tdtu;

public interface BrewStrategy {
    void brewCoffee();
}
