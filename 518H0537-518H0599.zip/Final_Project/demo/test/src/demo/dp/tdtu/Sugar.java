package demo.dp.tdtu;

public class Sugar {
    public void addSugar() {
        System.out.println("Adding sugar...");
    }
}
