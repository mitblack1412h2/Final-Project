package demo.dp.tdtu;

public class FrenchPressStrategy implements BrewStrategy{
    public void brewCoffee() {
        System.out.println("Pressing coffee grounds with hot water...");
    }
}
